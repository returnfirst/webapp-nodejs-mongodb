const express = require('express');

const app = express();

console.log(app);