module.exports = {
    index (req, res) {
        res.sendFile('index.html');
    }
};