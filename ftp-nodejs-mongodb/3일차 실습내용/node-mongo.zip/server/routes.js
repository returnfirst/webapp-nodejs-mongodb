const express = require('express');
const router = express.Router();
const home = require('../controllers/home');
const auth = require('../controllers/auth');
const user = require('../controllers/user');
const ssam = require('../controllers/ssam');
const movie = require('../controllers/movie');

module.exports = function (app) {

    router.get('/', home.index);

    router.get('/login', auth.login);
    router.get('/logon', auth.logon);

    router.get('/movie/starwars', movie.viewAll);

    router.post('/users', user.registUser);
    router.post('/users/json', user.registUserWithJson);
    router.get('/users', user.viewUsers);

    router.get('/ssam', ssam.viewSsams);
    router.get('/ssam/:bbs', ssam.bbs);
    router.get('/ssam/:bbs/:articleNo', ssam.article);

    app.use(router);
};