// const add = function(a, b) {
//     return a + b;
// };
//
// const sub = function(a, b) {
//     return a - b;
// };
//
// module.exports.add = add;
// module.exports.sub = sub;

const calc = {
    add: function(a, b) { return a + b; },
    sub: function(a, b) { return a - b; },
};

module.exports = calc;