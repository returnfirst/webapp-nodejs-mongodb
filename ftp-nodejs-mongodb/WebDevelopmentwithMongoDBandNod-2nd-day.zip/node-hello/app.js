const express = require('express');

const app = express();

app.get('/', function(req, res) {
    res.send('hello root request..');
});

app.post('/', function(req, res) {

});

app.get('/user', function(req, res) {
    res.send('<h1>안녕하세요 김순곤 님</h1>')
});

app.get('/user/soongon', function(req, res) {
    res.send('<h2>김순곤님 노드세계에 오신걸 합니다.</h2>')
});



app.listen(3000, function () {
    console.log('server ready on 3000');
});