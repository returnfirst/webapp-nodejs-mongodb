

console.log(add(3, 5));