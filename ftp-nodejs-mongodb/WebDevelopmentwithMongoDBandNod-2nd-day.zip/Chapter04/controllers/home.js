module.exports = {
    index (req, res){
        res.send('The home:index controller');
    }
};
