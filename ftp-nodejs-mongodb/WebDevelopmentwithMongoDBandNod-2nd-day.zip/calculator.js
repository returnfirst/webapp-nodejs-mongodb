
const calc = require('./superCalc');



let numOne = 15;
let numTwo = 20;

let result = calc.sub(numOne, numTwo);

console.log(result);