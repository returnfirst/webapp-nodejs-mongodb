console.log('hello');

let a = 1;
let e = 3.14;

let b = '3'; // "3"

let c = true;
let d = false;

console.log(typeof d);

const h = function() {

    console.log('hi');

};
h();

myFunc();



function myFunc() {
    console.log('camel case');
}

const f = [1,2,3,4,5,6];
//var g = new Array(1,2,3);

console.log(f[3]);

f.reverse();

console.log(f);

// object, JSON

const o = {
    name: 'kim soongon',
    addr: 'seoul',
    home: 'gyoung-ju',
    age: 40,
    friend: {
        name: 'hong',
        age: 40
    },
    hobby: ['music', 'coding', 'reading'],
    singASong: function() {
        console.log('song song..');
    }
};

o.hobby.push('drinking');

o.hobby.forEach(function(item) {
    console.log(item);
});

